Agreement:
 - You are not allowed to redistribute Complementary. Always direct people to the official download pages: 

<a href="https://www.curseforge.com/minecraft/customization/complementary-shaders/">https://www.curseforge.com/minecraft/customization/complementary-shaders/</a>
<a href="https://github.com/gri573/Complementary_SSPT/">https://github.com/gri573/Complementary_SSPT/</a>

 - You are allowed to use Complementary for streaming, videos, screenshots. Crediting and keeping the pack updated is preferable but not mandatory.
 - You are allowed to publish any Complementary edits under these terms:
	1) Your edit must be clearly distinguishable from Complementary in terms of general in-game looks.
	2) You must not use the word "Complementary" or words that are very similar to that (like Complimentary, Supplementary, Compomentary, Conpelantary) in your edit's name.
	3) You must visibly credit both BSL Shaders (Capt Tatsu) and Complementary Shaders (EminGT) in your edit's description.
	4) You must allow other people to publish edits of your edit without putting terms stricter than Complementary's.
	5) Term #2 can be ignored if the actual Complementary Shaders haven't been updated at all for more than a year at the time you're releasing your edit.
	6) My and EminGT's permission can lift the terms #1 and #2.
